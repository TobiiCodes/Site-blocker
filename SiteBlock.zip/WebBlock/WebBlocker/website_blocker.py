import os
import ctypes
import sys

# Path to the hosts file
HOSTS_PATH = "C:\\Windows\\System32\\drivers\\etc\\hosts" if os.name == 'nt' else "/etc/hosts"
# IP address to redirect to (localhost)
REDIRECT_IP = "127.0.0.1"

# List of websites to block on the first run
# List of websites to block
WEBSITES_TO_BLOCK = [
    "pornhub.com",
    "xvideos.com",
    "xhamster.com",
    "xnxx.com",
    "youporn.com",
    "redtube.com",
    "beeg.com",
    "txxx.com",
    "eporner.com",
    "tube8.com",
    "fuq.com",
    "porntube.com",
    "letmejerk.com",
    "porndoe.com",
    "superporn.com",
    "ixxx.com",
    "porn.com",
    "thumbzilla.com",
    "tubegalore.com",
    "smutr.com",
    "iwank.com",
    "hdhole.com",
    "4tube.com",
    "anysex.com",
    "tubev.com",
    "tubesafari.com",
    "hqporner.com",
    "thisvid.com",
    "porn300.com",
    "ozeex.com",
    "4porn.com",
    "shameless.com",
    "megatube.com",
    "youx.com",
    "sexvid.com",
    "fux.com",
    "anybunny.com",
    "melonstube.com",
    "zbporn.com",
    "porndroids.com",
    "largehdtube.com",
    "bigporn.com",
    "pornid.com",
    "tiava.com",
    "cliphunter.com",
    "assoass.com",
    "forhertube.com",
    "pornerbros.com",
    "ok.com",
    "xxxbunker.com",
    "pornheed.com",
    "lobstertube.com",
    "dinotube.com",
    "ufreeporn.com",
    "hotporntubes.com",
    "porngrey.com",
    "palmtube.com",
    "viviporn.com",
    "pornfaze.com",
    "fapster.com",
    "pornito.com",
    "slutroulette.com",
    "jerkmate.com",
    "camsoda.com",
    "ichatonline.com",
    "liveporngirls.com",
    "milfslive.com",
    "naughtyamerica.com",
    "bangbrosnetwork.com",
    "bang.com",
    "teamskeet.com",
    "dogfartnetwork.com",
    "mofosnetwork.com",
    "21sextury.com",
    "babesnetwork.com",
    "digitalplayground.com",
    "hentaihaven.com",
    "xvideoshentai.com",
    "fakku.com",
    "nhentai.com",
    "spankbang.com",
    "myhentaicomics.com",
    "myhentaigallery.com",
    "porcore.com",
    "cartoonporno.com",
    "nutaku.com",
    "porngameshub.com",
    "gamcore.com",
    "gamesofdesire.com",
    "porngames.com",
    "sexemulator.com"
]

# Path to a temporary file to track initial setup
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TEMP_SETUP_FILE = os.path.join(SCRIPT_DIR, "initial_setup_done.txt")

def perform_initial_setup():
    """Perform initial setup if it has not been completed yet."""
    if not os.path.exists(TEMP_SETUP_FILE):
        print("Performing initial setup...")
        for website in WEBSITES_TO_BLOCK:
            block_website(website)
        with open(TEMP_SETUP_FILE, 'w') as file:
            file.write("Initial setup completed.")
        print("Initial setup completed.")
    else:
        print("Initial setup has already been completed.")

def is_admin():
    try:
        # Check for Windows
        if os.name == 'nt':
            return ctypes.windll.shell32.IsUserAnAdmin()
        # Check for Unix-based systems
        else:
            return os.geteuid() == 0
    except AttributeError:
        return False

def block_website(website):
    # Strip 'http://', 'https://', and 'www.' from the website URL
    website = website.replace('http://', '').replace('https://', '').replace('www.', '')
    with open(HOSTS_PATH, 'r+') as file:
        content = file.read()
        if website not in content:
            # Add the website to the hosts file
            file.write(f"{REDIRECT_IP} {website}\n")
            file.write(f"{REDIRECT_IP} www.{website}\n")
            print(f"Blocked {website}")
        else:
            print(f"{website} is already blocked")

def unblock_website(website):
    # Strip 'http://', 'https://', and 'www.' from the website URL
    website = website.replace('http://', '').replace('https://', '').replace('www.', '')
    with open(HOSTS_PATH, 'r') as file:
        lines = file.readlines()
    with open(HOSTS_PATH, 'w') as file:
        for line in lines:
            if website not in line and f"www.{website}" not in line:
                file.write(line)
    print(f"Unblocked {website}")

def main():
    perform_initial_setup()
    while True:
        action = input("Do you want to block or unblock a website? (block/unblock/exit): ").strip().lower()
        if action in ['block', 'unblock']:
            website = input("Enter the website URL (without http/https): ").strip().lower()
            if action == 'block':
                block_website(website)
            elif action == 'unblock':
                unblock_website(website)
        elif action == 'exit':
            break
        else:
            print("Invalid action. Please enter 'block', 'unblock', or 'exit'.")

if __name__ == "__main__":
    if not is_admin():
        print("Please run this script as an administrator.")
    else:
        main()

